import AppLayout from "../components/AppLayout";

export default function Profile() {
  return (
    <AppLayout>
      <h2 className="text-2xl font-black mb-2">Perfil</h2>
      <p className="text-zinc-400 text-sm">Em breve: login + admin</p>
    </AppLayout>
  );
}
