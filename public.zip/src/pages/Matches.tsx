import { useEffect, useState } from "react";
import { collection, onSnapshot, orderBy, query, limit, Timestamp, where } from "firebase/firestore";

import { db } from "../lib/firebase";
import AppLayout from "../components/AppLayout";
import { useAuth } from "../lib/auth";
import MatchCard from "../components/MatchCard";



type MatchDoc = {
  teamA?: string;
  teamB?: string;
  competition?: string;
  round?: string;
  allowDraw?: boolean;
  winner?: string | null;
  deadline?: Timestamp | null;
};

type MatchView = {
  id: string;
  teamA: string;
  teamB: string;
  competition: string;
  round: string;
  allowDraw: boolean;
  winner: string | null;
  deadlineText: string;
};

export default function Matches() {
    const { user } = useAuth();
    const [myVotes, setMyVotes] = useState<Record<string, string>>({});
  const [items, setItems] = useState<MatchView[]>([]);
  const [status, setStatus] = useState<string>("Carregando confrontos...");

  useEffect(() => {
    try {
      const q = query(
        collection(db, "matches"),
        orderBy("deadline", "asc"),
        limit(50)
      );

      const unsub = onSnapshot(
        q,
        (snap) => {
          const list: MatchView[] = snap.docs.map((d) => {
            const data = d.data() as MatchDoc;
            const dt = data.deadline ? data.deadline.toDate() : null;

            return {
              id: d.id,
              teamA: data.teamA ?? "-",
              teamB: data.teamB ?? "-",
              competition: data.competition ?? "-",
              round: data.round ?? "-",
              allowDraw: data.allowDraw ?? false,
              winner: (data.winner as string | null) ?? null,
              deadlineText: dt ? dt.toLocaleString() : "-"
            };
          });

          setItems(list);
          setStatus(list.length ? "" : "Nenhum confronto encontrado em /matches.");
        },
        (err) => {
          console.error(err);
          setStatus(
            "Erro ao ler /matches. Provável: permissões do Firestore exigem login. " +
              "Mensagem: " +
              (err?.message || String(err))
          );
        }
      );

      return () => unsub();
    } catch (e: any) {
      console.error(e);
      setStatus("Falha inesperada ao iniciar Firestore: " + (e?.message || String(e)));
    }
  }, []);

  useEffect(() => {
  if (!user?.uid) return;

  const q = query(
    collection(db, "guesses"),
    where("userId", "==", user.uid),
    limit(500)
  );

  const unsub = onSnapshot(
    q,
    (snap) => {
      const map: Record<string, string> = {};
      snap.docs.forEach((d) => {
        const data = d.data() as any;
        if (data?.matchId && data?.guess) {
          map[String(data.matchId)] = String(data.guess);
        }
      });
      setMyVotes(map);
    },
    (err) => {
      console.error(err);
      // não trava a tela
    }
  );

  return () => unsub();
}, [user?.uid]);


  return (
  <AppLayout>
    <div className="flex items-end justify-between mb-4">
      <div>
        <h2 className="text-2xl font-black">Confrontos</h2>
        <p className="text-zinc-400 text-sm">Teste Firestore (já vamos evoluir)</p>
      </div>
    </div>

    {status && (
      <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-200 mb-4">
        {status}
      </div>
    )}

    <div className="grid gap-3">
  {items.map((m) => (
    <MatchCard
      key={m.id}
      match={m}
      myVote={myVotes[m.id] ?? null}
      onVoteClick={(vote) => {
        // ✅ neste passo (7.1) não salva ainda, só mostra no console
        console.log("clicou voto", m.id, vote);
      }}
    />
  ))}
</div>

  </AppLayout>
);
}
