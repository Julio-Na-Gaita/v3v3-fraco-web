import AppLayout from "../components/AppLayout";

export default function Ranking() {
  return (
    <AppLayout>
      <h2 className="text-2xl font-black mb-2">Ranking</h2>
      <p className="text-zinc-400 text-sm">Em breve: ranking premium</p>
    </AppLayout>
  );
}
