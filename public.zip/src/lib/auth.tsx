import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { User } from "firebase/auth";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from "firebase/auth";

import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db } from "./firebase";

type AppUser = {
  uid: string;
  name: string;
  username: string;
  isAdmin: boolean;
};

type AuthCtx = {
  firebaseUser: User | null;
  user: AppUser | null;
  loading: boolean;
  loginWithUsername: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthCtx | null>(null);

// ✅ Igual no Android:
function gerarEmail(usuario: string) {
  return `${usuario.trim().toLowerCase()}@bolao112.com`;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);

      if (!fbUser) {
        setUser(null);
        setLoading(false);
        return;
      }

      try {
        const ref = doc(db, "users", fbUser.uid);
        const snap = await getDoc(ref);

        // Atualiza lastAccess/appVersion (merge, não quebra se doc não existir)
        await setDoc(
          ref,
          {
            appVersion: "Web 0.1",
            lastAccess: serverTimestamp(),
          },
          { merge: true }
        );

        const data = snap.exists() ? (snap.data() as any) : {};

        const username =
          (data?.username as string | undefined) ??
          (fbUser.email ? fbUser.email.split("@")[0] : "usuario");

        const name = (data?.name as string | undefined) ?? username;
        const isAdmin = (data?.isAdmin as boolean | undefined) ?? false;

        setUser({
          uid: fbUser.uid,
          username,
          name,
          isAdmin,
        });
      } catch (e) {
        console.error(e);
        // Se der erro no Firestore, ainda mantém autenticado no Auth
        setUser({
          uid: fbUser.uid,
          username: fbUser.email ? fbUser.email.split("@")[0] : "usuario",
          name: fbUser.email ? fbUser.email.split("@")[0] : "usuario",
          isAdmin: false,
        });
      } finally {
        setLoading(false);
      }
    });

    return () => unsub();
  }, []);

  const loginWithUsername = async (username: string, password: string) => {
    const email = gerarEmail(username);
    await signInWithEmailAndPassword(auth, email, password);
  };

  const logout = async () => {
    await signOut(auth);
  };

  const value = useMemo<AuthCtx>(
    () => ({ firebaseUser, user, loading, loginWithUsername, logout }),
    [firebaseUser, user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider />");
  return ctx;
}
