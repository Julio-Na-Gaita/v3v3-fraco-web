import { MessageSquareText, Users, Eye } from "lucide-react";

type MatchView = {
  id: string;
  teamA: string;
  teamB: string;
  competition: string;
  round: string;
  allowDraw: boolean;
  winner: string | null;

  deadline: Date | null;
  deadlineLabel: string;

  teamALogo?: string;
  teamBLogo?: string;

  votesA?: number;
  votesB?: number;
  votesD?: number;
  totalUsers?: number;
  matchNumber?: number;
};

type Props = {
  match: MatchView;
  myVote: string | null; // "A" | "B" | "EMPATE" | null
  onVoteClick: (vote: "A" | "B" | "EMPATE") => void;
};

function LogoBox({
  name,
  logo,
  selected,
  disabled,
  onClick,
}: {
  name: string;
  logo?: string;
  selected: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  const showImg = !!logo && (logo.startsWith("http") || logo.startsWith("data:image"));
  const initials =
    name && name !== "-"
      ? name
          .split(" ")
          .slice(0, 2)
          .map((s) => s[0]?.toUpperCase())
          .join("")
      : "?";

  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={[
        "w-[140px] max-w-[40%] rounded-3xl p-3 transition",
        "bg-white/85 backdrop-blur border shadow-sm",
        selected ? "border-emerald-400 ring-2 ring-emerald-300/60" : "border-white/60",
        disabled ? "opacity-65 cursor-not-allowed" : "hover:shadow-md",
      ].join(" ")}
    >
      <div className="w-full aspect-square rounded-2xl bg-zinc-100 flex items-center justify-center overflow-hidden">
        {showImg ? (
          <img src={logo} alt={name} className="w-full h-full object-contain" />
        ) : (
          <div className="text-zinc-500 font-black text-2xl">{initials}</div>
        )}
      </div>
      <div className="mt-2 text-center font-black text-zinc-900 text-sm leading-4">
        {name}
      </div>
    </button>
  );
}

function CenterBox({
  allowDraw,
  selected,
  disabled,
  onClick,
}: {
  allowDraw: boolean;
  selected: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  // quando NÃO permite empate, é só um “X” decorativo como no mata-mata
  if (!allowDraw) {
    return (
      <div className="w-[110px] max-w-[28%] rounded-3xl p-3 bg-white/60 border border-white/60 backdrop-blur flex flex-col items-center justify-center">
        <div className="text-zinc-400 font-black text-4xl leading-none">X</div>
      </div>
    );
  }

  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={[
        "w-[110px] max-w-[28%] rounded-3xl p-3 transition",
        "bg-white/80 backdrop-blur border shadow-sm flex flex-col items-center justify-center",
        selected ? "border-emerald-400 ring-2 ring-emerald-300/60" : "border-white/60",
        disabled ? "opacity-65 cursor-not-allowed" : "hover:shadow-md",
      ].join(" ")}
    >
      <div className="text-zinc-300 font-black text-5xl leading-none">X</div>
      <div className="mt-1 text-zinc-800 font-black text-xs tracking-wide">EMPATE</div>
    </button>
  );
}

export default function MatchCard({ match, myVote, onVoteClick }: Props) {
  const isClosed = !!match.winner || (match.deadline ? Date.now() > match.deadline.getTime() : false);

  const votesA = match.votesA ?? 0;
  const votesD = match.votesD ?? 0;
  const votesB = match.votesB ?? 0;
  const voted = votesA + votesD + votesB;

  const totalUsers =
    match.totalUsers ?? (voted > 0 ? voted : 0); // fallback simples

  const pctVoted = totalUsers > 0 ? Math.round((voted / totalUsers) * 100) : null;

  // barras (se não tiver dados, fica cinza “neutro”)
  const wA = totalUsers > 0 ? (votesA / totalUsers) * 100 : 0;
  const wD = totalUsers > 0 ? (votesD / totalUsers) * 100 : 0;
  const wB = totalUsers > 0 ? (votesB / totalUsers) * 100 : 0;
  const wN = totalUsers > 0 ? Math.max(0, 100 - (wA + wD + wB)) : 100;

  return (
    <div className="rounded-[28px] border border-white/20 shadow-xl overflow-hidden">
      {/* “plano de fundo” premium */}
      <div className="bg-gradient-to-br from-emerald-200/80 via-sky-200/70 to-white/70 p-4">
        {/* Cabeçalho */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-zinc-600 font-black tracking-wide text-xs">
              {match.matchNumber != null ? `#${match.matchNumber} • ` : ""}
              {match.competition}
            </div>
            <div className="text-zinc-500 font-bold text-xs mt-1">{match.round}</div>
            <div className="text-red-600 font-black text-sm mt-2">{match.deadlineLabel}</div>
          </div>

          {/* ícones (por enquanto só visual) */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-white/70 border border-white/60 backdrop-blur flex items-center justify-center">
              <MessageSquareText size={18} className="text-zinc-700" />
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white/70 border border-white/60 backdrop-blur flex items-center justify-center">
              <Eye size={18} className="text-zinc-700" />
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white/70 border border-white/60 backdrop-blur flex items-center justify-center">
              <Users size={18} className="text-zinc-700" />
            </div>
          </div>
        </div>

        {/* Corpo (tiles) */}
        <div className="mt-4 flex items-center justify-between gap-3">
          <LogoBox
            name={match.teamA}
            logo={match.teamALogo}
            selected={myVote === "A"}
            disabled={isClosed}
            onClick={() => onVoteClick("A")}
          />

          <CenterBox
            allowDraw={match.allowDraw}
            selected={myVote === "EMPATE"}
            disabled={isClosed}
            onClick={() => onVoteClick("EMPATE")}
          />

          <LogoBox
            name={match.teamB}
            logo={match.teamBLogo}
            selected={myVote === "B"}
            disabled={isClosed}
            onClick={() => onVoteClick("B")}
          />
        </div>

        {/* Rodapé — termômetro/engajamento (se tiver dados, mostra de verdade) */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs font-bold text-zinc-600">
            <span>Engajamento da Galera</span>
            <span>{pctVoted == null ? "—" : `${pctVoted}% votaram`}</span>
          </div>

          <div className="mt-2 h-3 rounded-full overflow-hidden bg-zinc-200 border border-white/60">
            <div className="h-full flex">
              <div style={{ width: `${wA}%` }} className="bg-emerald-600" />
              <div style={{ width: `${wD}%` }} className="bg-zinc-600" />
              <div style={{ width: `${wB}%` }} className="bg-red-600" />
              <div style={{ width: `${wN}%` }} className="bg-zinc-300" />
            </div>
          </div>

          <div className="mt-2 text-[11px] text-zinc-600 flex items-center justify-between">
            <span>{match.teamA}: {votesA}</span>
            {match.allowDraw ? <span>Empate: {votesD}</span> : <span />}
            <span>{match.teamB}: {votesB}</span>
          </div>

          <div className="mt-1 text-[11px] text-zinc-500 text-right">
            {totalUsers > 0 ? `${voted} de ${totalUsers} participantes` : "— participantes"}
          </div>
        </div>
      </div>
    </div>
  );
}
