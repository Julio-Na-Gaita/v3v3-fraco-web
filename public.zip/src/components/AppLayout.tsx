import { Link, useLocation } from "react-router-dom";
import bgHome from "../assets/android/bg/bg_home.png";


function NavItem({ to, label }: { to: string; label: string }) {
  const { pathname } = useLocation();
  const active = pathname === to;

  return (
    <Link
      to={to}
      className={[
        "px-4 py-2 rounded-xl text-sm font-black tracking-wide transition",
        active
          ? "bg-zinc-100 text-zinc-900 shadow"
          : "text-zinc-200 hover:bg-zinc-800 hover:text-zinc-50",
      ].join(" ")}
    >
      {label}
    </Link>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-full">
      {/* Top bar */}
      <div className="sticky top-0 z-10 backdrop-blur bg-zinc-950/80 border-b border-zinc-800">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-zinc-100 text-zinc-900 flex items-center justify-center font-black">
              V3
            </div>
            <div>
              <div className="text-base font-black leading-4">V3v3 é Fraco FC</div>
              <div className="text-xs text-zinc-400">Versão Web</div>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2">
            <NavItem to="/confrontos" label="CONFRONTOS" />
            <NavItem to="/ranking" label="RANKING" />
            <NavItem to="/perfil" label="PERFIL" />
          </div>
        </div>

        {/* Mobile tabs */}
        <div className="sm:hidden max-w-5xl mx-auto px-4 pb-3 flex gap-2">
          <NavItem to="/confrontos" label="CONFRONTOS" />
          <NavItem to="/ranking" label="RANKING" />
          <NavItem to="/perfil" label="PERFIL" />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-4 py-6">{children}</div>
    </div>
  );
}
