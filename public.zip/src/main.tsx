import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./index.css";
import { AuthProvider } from "./lib/auth";
import RequireAuth from "./components/RequireAuth";


import Login from "./pages/Login";
import Matches from "./pages/Matches";
import Ranking from "./pages/Ranking";
import Profile from "./pages/Profile";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/confrontos" element={<RequireAuth><Matches /></RequireAuth>} />
        <Route path="/ranking" element={<RequireAuth><Ranking /></RequireAuth>} />
        <Route path="/perfil" element={<RequireAuth><Profile /></RequireAuth>} />

        {/* padrão: manda para confrontos */}
        <Route path="/" element={<Navigate to="/confrontos" replace />} />
        <Route path="*" element={<Navigate to="/confrontos" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
  </React.StrictMode>
);
